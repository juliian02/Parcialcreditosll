from django.shortcuts import render
# Create your views here.
from django.views.generic import TemplateView, ListView, CreateView, UpdateView, DeleteView, DetailView

from .models import LibroAg
from .forms import LibroAgForm
from .models import PrestamosAg
from .forms import PrestamosAgForm
from .models import UsuariosAg
from .forms import UsuariosAgForm
from .models import AutorAg
from .forms import AutorAgForm

class AutorCreateView(CreateView):
    model = AutorAg
    template_name = 'autor.html'
    form_class = AutorAgForm
    success_url = '/agregarautor'

class LibroCreateView(CreateView):
    model = LibroAg
    template_name = 'libro.html'
    form_class = LibroAgForm
    success_url = '/agregarLibro'

class PrestamoCreateView(CreateView):
    model = PrestamosAg
    template_name = 'prestamo.html'
    form_class = PrestamosAgForm
    success_url = '/agregarPrestamo'

class UsuariosCreateView(CreateView):
    model = UsuariosAg
    template_name = 'usuario.html'
    form_class = UsuariosAgForm
    success_url = '/agregarUsuer'

class Libro_aListView(ListView):
    template_name = "home.html"
    model = LibroAg
    context_object_name = 'lista_l'


class Prestamo_aListView(ListView):
    template_name = "home1.html"
    model = PrestamosAg
    context_object_name = 'lista_p'


class Usuarios_aListView(ListView):
    template_name = "home2.html"
    model = UsuariosAg
    context_object_name = 'lista_u'


class Autor_aListView(ListView):
    template_name = "home3.html"
    model = AutorAg
    context_object_name = 'lista_a'

class actualizarPrestamo(UpdateView):
    model = PrestamosAg
    form_class = PrestamosAgForm
    template_name = 'prestamo.html'
    success_url = "/ListarPrestamo"

class actualizarUsuario(UpdateView):
    model = UsuariosAg
    form_class = UsuariosAgForm
    template_name = 'usuario.html'
    success_url = "/ListarUser"

class actualizarAutor(UpdateView):
    model = AutorAg
    form_class = AutorAgForm
    template_name = 'autor.html'
    success_url = "/Listarautor"