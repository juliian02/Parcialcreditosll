from django.contrib import admin
from django.urls import path,re_path
from django.conf.urls import url, include

from.import views

urlpatterns = [
path('agregarautor/', views.AutorCreateView.as_view()),
path('agregarLibro/', views.LibroCreateView.as_view()),
path('agregarUsuer/', views.UsuariosCreateView.as_view()),
path('agregarPrestamo/', views.PrestamoCreateView.as_view()),
path('ListarLibro/', views.Libro_aListView.as_view()),
path('ListarPrestamo/', views.Prestamo_aListView.as_view()),
path('ListarUser/', views.Usuarios_aListView.as_view()),
path('Listarautor/', views.Autor_aListView.as_view()),
path('actualizarPrestamo/<int:pk>/',views.actualizarPrestamo.as_view(), name='editarprestamos'),
path('actualizarUser/<int:pk>/',views.actualizarUsuario.as_view(), name='editarUser'),
path('actualizarAutor/<int:pk>/',views.actualizarAutor.as_view(), name='editarautor'),
]