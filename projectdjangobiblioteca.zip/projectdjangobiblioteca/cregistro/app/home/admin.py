from django.contrib import admin

from .models import LibroAg, PrestamosAg, UsuariosAg, AutorAg

# Register your models here.
admin.site.register(LibroAg)
admin.site.register(AutorAg)
admin.site.register(UsuariosAg)
admin.site.register(PrestamosAg)


