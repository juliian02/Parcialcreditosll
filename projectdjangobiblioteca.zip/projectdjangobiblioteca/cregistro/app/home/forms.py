from django import forms 

from .models import LibroAg, PrestamosAg, UsuariosAg, AutorAg

class LibroAgForm(forms.ModelForm):
    """Form definition for LibroAg."""

    class Meta:
        """Meta definition for LibroAg."""

        model = LibroAg
        fields = ('__all__')
        widgets = {'id_libros': forms.TextInput(attrs={'class':'form-control'}),
         'codigo':forms.TextInput(attrs={'class':'form-control'}),
         'titulo': forms.TextInput(attrs={'class':'form-control'}),
         'ISBN': forms.TextInput(attrs={'class':'form-control'}),
         'editorial':forms.TextInput(attrs={'class':'form-control'}), 
         'num_pags': forms.TextInput(attrs={'class':'form-control'})}

class PrestamosAgForm(forms.ModelForm):
    """Form definition for PrestamosAg."""

    class Meta:
        """Meta definition for PrestamosAg."""

        model = PrestamosAg
        fields = ('__all__')
        widgets = {'id_prestamo': forms.TextInput(attrs={'class':'form-control'}),
         'libro': forms.Select(attrs={'class':'form-control', 'placeholder':'seleccione'}), 
         'usuarios': forms.Select(attrs={'class':'form-control', 'placeholder':'seleccione'}), 
         'fecha_prestamo':forms.DateInput(attrs={'class':'form-control','type':'date'}), 
         'fecha_devolucion': forms.DateInput(attrs={'class':'form-control','type':'date'})}

class UsuariosAgForm(forms.ModelForm):
    """Form definition for UsuariosAg."""

    class Meta:
        """Meta definition for UsuariosAg."""

        model = UsuariosAg
        fields = ('__all__')
        widgets = {'id_usuario': forms.TextInput(attrs={'class':'form-control'}),
         'usuario':forms.TextInput(attrs={'class':'form-control'}), 
         'nombre':forms.TextInput(attrs={'class':'form-control'}),
         'direccion':forms.TextInput(attrs={'class':'form-control'}),
         'telefono':forms.TextInput(attrs={'class':'form-control'})}


class AutorAgForm(forms.ModelForm):
    """Form definition for AutorAg."""

    class Meta:
        """Meta definition for AutorAg."""

        model = AutorAg
        fields = ('__all__')
        widgets = {'id_autor': forms.TextInput(attrs={'class':'form-control'}),
         'nombre':forms.TextInput(attrs={'class':'form-control'}), 
         'nacionalidad':forms.TextInput(attrs={'class':'form-control'})}