from django.db import models

# Create your models here.


class AutorAg(models.Model):
    id_autor = models.CharField(max_length=100, primary_key=True)
    nombre = models.CharField(max_length=100)
    nacionalidad = models.CharField(max_length=30)


    def __str__(self):
       return self.id_autor 

class LibroAg(models.Model):
    id_libros =  models.CharField(max_length=100, primary_key=True)
    codigo = models.IntegerField()
    titulo = models.CharField(max_length=100)
    ISBN = models.CharField(max_length=30)
    editorial = models.CharField(max_length=60)
    num_pags =  models.IntegerField()


    def __str__(self):
       return self.id_libros 

class UsuariosAg(models.Model):
    id_usuario =  models.CharField(max_length=100, primary_key=True)
    usuario = models.CharField(max_length=100)
    nombre = models.CharField(max_length=100)
    direccion = models.CharField(max_length=100)
    telefono = models.IntegerField()

    def __str__(self):
       return self.id_usuario
    
class PrestamosAg(models.Model):
    id_prestamo =  models.CharField(max_length=100, primary_key=True)
    libro = models.ForeignKey(LibroAg, on_delete=models.CASCADE)
    usuarios = models.ForeignKey(UsuariosAg, on_delete=models.CASCADE)
    fecha_prestamo = models.DateField(max_length=100)
    fecha_devolucion = models.DateField(max_length=100)


    def __str__(self):
       return self.id_prestamo    

